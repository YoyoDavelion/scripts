import requests, re, os, time
url = "https://www.goikofriends.com/QR/aura?r=0&aura.ApexAction.execute=1"
def clear():
 os.system('cls || clear')
r = requests.session()
r.get(url)
price = '56.4'
ticket = str(input("Introduce el numero de ticket a comprobar: "))
data = {
    'message' : '{"actions":[{"id":"2;a","descriptor":"aura://ApexActionController/ACTION$execute","callingDescriptor":"UNKNOWN","params":{"namespace":"","classname":"R3_CLS_RegistrationHomePage_CTRL","method":"saveParticipante","params":{"personEmail":"sofsan2003@gmail.com","ticketCompra":"%s","precioPedido":"%s","localId":"37720"},"cacheable":false,"isContinuation":false}}]}' %(ticket, price),
    'aura.context' : '{"mode":"PROD","fwuid":"QPQi8lbYE8YujG6og6Dqgw","app":"c:LightningOutApp","loaded":{"APPLICATION@markup://c:LightningOutApp":"8NJanl9k5lwJ75NQBv8HUQ"},"dn":[],"globals":{},"uad":true}',
    'aura.pageURI' : '/QR?receiptId=110470',
    'companyId' : '37720',
    'aura.token' : 'null'
}
response = r.post(url, data=data)
message = re.findall('"message":"(.*?)"', response.text)
message = message[0]
print(message)
if "Ticket no existente o fuera del periodo de 24 horas" in message:
    print("El ticket no existe")
    print("Output del servidor: " + message)
    
else:
    print("El ticket existe")
    print("Output del servidor: " + message)