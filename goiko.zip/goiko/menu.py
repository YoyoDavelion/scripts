import os
def menu_dic():
    base_price = 13.90
    for i in range (1,16):
        menu_price = round(base_price * i, 1)
        os.system('echo {}>>menudic.txt'.format(menu_price))
base = 110818
for i in range(0,50):
    base+=1
    os.system('echo {}>>tickets.txt'.format(base))
