import os
price = "2,70"
first_10 = 0
for euro in range (10,100):
    first_10 = 0
    for centimos in range(0,100):
        if first_10 < 10:
            price = (str(euro) + "." + "0" + str(centimos))
            os.system('echo {}>> min10eprices.txt'.format(price))
        else:
            price = (str(euro) + "." + str(centimos))
            os.system('echo {}>> min10eprices.txt'.format(price))
        first_10 += 1



